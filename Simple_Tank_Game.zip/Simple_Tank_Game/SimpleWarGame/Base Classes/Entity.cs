using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// Abstract Base class for all character agents (AKA Entities).
    /// Every Entity has Health, Armor, and MaxHealth properties.
    /// Every Entity has Attack and Defend methods.
    /// </summary>
    /// 



    public abstract class Entity : GameObject
    {
        private double health;
        private double armor;


        Player player { get; set; }
        public double Health
        {
            get { return health; }
            set { health = value; }
        }

        public double Armor
        {
            get { return armor; }
            set { armor = value; }
        }



        public double MaxHealth
        { get { return health; } } 



        virtual public void Attack(Player player)
        {
            //player.Health -= Weapon.Damage;



        }
  
        public void Defend()
        {

        }




    }
}
