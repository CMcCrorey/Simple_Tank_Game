using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// Abstract base class for all weapons in the game.
    /// </summary>
    public abstract class Weapon : GameObject
    {

        public double Damage { get; set; }

        public double Attack_bonus { get; set; }



        public Weapon()
        {
           


        }

        
           

            


    }
}
