using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// Abstract Base Class for all other classes.
    /// Gives every inherited class the Name property.
    /// </summary>
    /// 


    public abstract class GameObject
    {

       string Name {get;set;}
            


    }
}
