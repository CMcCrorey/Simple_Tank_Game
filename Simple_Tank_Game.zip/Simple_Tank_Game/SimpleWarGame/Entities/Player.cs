using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// The Player class.  High Health and Armor. Uses various kinds of Ammo selected by the player.
    /// </summary>
    public class Player : Entity
    {
        Random random = new Random();
        public PiercingAmmo Weapon { get;  set; }
        public ExplodeAmmo  Weapon1 { get;  set; }

        //public Weapon Weapon;

        public Entity Target { get; set; }

        public Weapon weapon { get; set; }

        /// <summary>
        /// Player Constructor. Takes no arguments.
        /// Initalizies an Player to default values.
        /// </summary>
        public Player()
        {
            this.Health = 300;
            this.Armor = 100;
        }

        /// <summary>
        /// Allows the player to select which weapon they want to use.
        /// </summary>
        /// <param name="type">The weapon they would like to use. Check the weaponType enum for possible options.</param>
        public void SelectWeapon(weaponType type)
        {
            switch (type)
            {
                case weaponType.explosive:
                    this.weapon = new ExplodeAmmo();
                    break;
                case weaponType.piercing:
                    this.weapon = new PiercingAmmo();
                    break;
                case weaponType.missle:
                    this.weapon = new MissleAmmo();
                    break;
                case weaponType.slug:
                    this.weapon = new SlugAmmo();
                    break;

            }
        }

        /// <summary>
        /// Heals the player to maximum health.
        /// </summary>
        /// 


        //public void Get_weapon()
        //{

        //}

        public  void Attack(Entity Target)
        {
            if (random.Next(1, 10) == 3)  
                Console.WriteLine("Your attack missed");
            else
            {
                if (Target.Armor <= 0)
                {
                    Target.Armor = 0;
                    Target.Health -= this.weapon.Damage;

                }
                    
                else
                    Target.Armor -= this.weapon.Damage;

                Console.WriteLine("your attack hit and did {0} damage ", this.weapon.Damage);

            }

          
          
        }

        public void Defend()
        {
            if (random.Next(1, 5) == 3)
                Console.WriteLine(" You were too late");
            else
            {
                if (Armor > 0 )
                {
                    Armor = Armor * 1.4;
                }
                else
                {
                    
                    Console.WriteLine(" you were too banged up We couldnt repair armor");
                    return;
                }

               

                Console.WriteLine(" Fortfied position successful armor regenerated to {0}", Armor);
            }

        }



        public void Heal()
        {
            this.Health = this.MaxHealth;
            this.Armor = 100;
        }
    }
}
