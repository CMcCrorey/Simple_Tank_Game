using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// The EnemyTruck class.  Low Health and Armor. Uses Missle Ammo.
    /// </summary>
    /// 


   
    public class EnemyTruck : Entity
    {
        /// <summary>
        /// EnemyTruck Constructor. Takes no arguments.
        /// Initalizies an EnemyTruck to default values.
        /// </summary>
        /// 

        Random random = new Random();
        MissleAmmo missileammo = new MissleAmmo();
        public EnemyTruck()
        {
           this.Health = 100;
           this.Armor = 10;
            
        }



        public override void Attack(Player player)
        {

            if (random.Next(1, 10) == 3)
                Console.WriteLine("Enemy Truck attack missed you!");
            else
            {

                if (player.Armor <= 0)
                {
                    player.Armor = 0;
                    player.Health -= missileammo.Damage;

                }
                    
                else
                    player.Armor -= missileammo.Damage;

                Console.WriteLine("Enemy Truck attack hit and did {0} damage ", missileammo.Damage);

            }







        }




    }
}
