using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// The EnemyTank class.  High health and Armor. Uses Slug Ammo.
    /// </summary>
    public class EnemyTank : Entity
    {
        Random random = new Random();
        SlugAmmo slugammo = new SlugAmmo();
        
        /// <summary>
        /// EnemyTank Constructor. Takes no arguments.
        /// Initalizies an EnemyTank to default values.
        /// </summary>
        public EnemyTank()
        {
            Health = 150;
            Armor = 50;

        }



        public override void Attack(Player player)
        {
            if (random.Next(1, 10) == 3)
                Console.WriteLine("Enemy Tank attack missed you!");
            else
            {
                if (player.Armor <= 0)
                {
                    player.Armor = 0;
                    player.Health -= slugammo.Damage;
                }
                else
                    player.Armor -= slugammo.Damage;

                Console.WriteLine("Enemy Tank attack hit and did {0} damage ", slugammo.Damage);
            }



          


        }




    }
}
