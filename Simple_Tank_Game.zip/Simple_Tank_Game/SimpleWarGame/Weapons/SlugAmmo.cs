using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// SlugAmmo is a type of Weapon. 
    /// Has low bonus to attack.
    /// Percise but moderate damage.
    /// </summary>
    public class SlugAmmo : Weapon
    {
        Random random = new Random();
        private const double ATTACKBONUS = 1.05;

        /// <summary>
        /// SlugAmmo Constructor. Takes no arguments.
        /// Sets default values.
        /// </summary>
        public SlugAmmo()
        {

            if (random.Next(1, 5) == 3)
            {
                Damage = 25;
            }
            else
            {
                Damage = 25;
                Damage = Damage * ATTACKBONUS;
            }




        

        }
    }
}
