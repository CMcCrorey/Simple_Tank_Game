using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// MissleAmmo is a type of Weapon. 
    /// Has high bonus to attack.
    /// Average damage spread with high damage.
    /// </summary>
    public class MissleAmmo : Weapon
    {
        Random random = new Random();
        private const double ATTACKBONUS = 1.3;
        /// <summary>
        /// MissleAmmo Constructor. Takes no arguments.
        /// Sets default values.
        /// </summary>
        public MissleAmmo()
        {



            if (random.Next(1, 5) == 3)
            {
                Damage = 40;
            }
            else
            {
                Damage = 40;
                Damage = Damage * ATTACKBONUS;
            }






        }
    }
}
